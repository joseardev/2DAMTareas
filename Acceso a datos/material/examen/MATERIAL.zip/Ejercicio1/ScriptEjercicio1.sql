DROP DATABASE IF EXISTS BDExamen_Ejercicio1;
GO
CREATE DATABASE BDExamen_Ejercicio1;
GO
USE BDExamen_Ejercicio1;
GO
CREATE TABLE Nomina (
  ID INT PRIMARY KEY IDENTITY,
  NombreEmpleado VARCHAR(100) NOT NULL,
  IDEmpleado INT NOT NULL,
  FechaPago DATE NOT NULL,
  SalarioBase MONEY NOT NULL,
  DiasTrabajados INT NOT NULL,
  HorasExtra INT NOT NULL,
  SalarioPorHora MONEY NOT NULL,
  SalarioPorHoraExtra MONEY NOT NULL,
  Asignaciones MONEY NOT NULL,
  Deducciones MONEY NOT NULL,
  TotalDevengado MONEY NOT NULL
);